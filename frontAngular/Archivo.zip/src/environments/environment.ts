export const environment = {
  production: false,
  apiBaseUrl: 'https://api-by6seszfzq-uc.a.run.app',
  apiKey: 'AIzaSyABYJgOvlJFDCfySRSdG2A20_n4J1jWYvc'
};
