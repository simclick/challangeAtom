import { Injectable } from '@angular/core';
const KEY = 'current_user_email';
@Injectable({ providedIn: 'root' })
export class SessionService {
  setEmail(email: string) { localStorage.setItem(KEY, email); }
  getEmail(): string | null { return localStorage.getItem(KEY); }
  clear() { localStorage.removeItem(KEY); }
}
