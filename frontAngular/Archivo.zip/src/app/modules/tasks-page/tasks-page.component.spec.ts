import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { TasksPageComponent } from './tasks-page.component';
import { ApiService } from '../../shared/services/api.service';
import { SessionService } from '../../shared/services/session.service';

class ApiMock {
  listTasks = jest.fn().mockReturnValue(of([]));
  addTask = jest.fn().mockReturnValue(of({ id: 't1', title: 'Nueva', userEmail: 'u', completed: false, createdAt: '2020-01-01T00:00:00Z' }));
  updateTask = jest.fn().mockReturnValue(of({ id: 't1', completed: true, title: 'Nueva', userEmail: 'u', createdAt: '2020-01-01T00:00:00Z' }));
  deleteTask = jest.fn().mockReturnValue(of(void 0));
}
class SessionMock { getEmail = () => 'u'; setEmail(){} clear(){} }

describe('TasksPageComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TasksPageComponent],
      providers: [
        { provide: ApiService, useClass: ApiMock },
        { provide: SessionService, useClass: SessionMock }
      ]
    }).compileComponents();
  });

  it('agrega tarea y aparece en el form array', () => {
    const fixture = TestBed.createComponent(TasksPageComponent);
    const c = fixture.componentInstance;
    c.addForm.setValue({ title: 'Nueva', description: '' });
    c.addTask();
    expect(c.tasksFA.length).toBe(1);
    expect(c.tasksFA.at(0).value.title).toBe('Nueva');
  });

  it('toggle completado llama updateTask', () => {
    const fixture = TestBed.createComponent(TasksPageComponent);
    const c = fixture.componentInstance;
    c['api'].listTasks = jest.fn().mockReturnValue(of([
      { id: 't1', title: 'T', userEmail: 'u', completed: false, createdAt: '2020-01-01T00:00:00Z' }
    ]));
    c.load();
    c.toggle(0, true);
    expect((c['api'] as any).updateTask).toHaveBeenCalledWith('t1', { completed: true });
  });
});
