import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../shared/services/api.service';
import { SessionService } from '../../shared/services/session.service';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../../shared/dialogs/confirm-dialog.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';

@Component({
  standalone: true,
  selector: 'app-login-page',
  imports: [CommonModule, ReactiveFormsModule, MatDialogModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent {
  private fb = inject(FormBuilder);
  private api = inject(ApiService);
  private session = inject(SessionService);
  private router = inject(Router);
  private dialog = inject(MatDialog);

  sending = false;

  form = this.fb.group({ email: ['', [Validators.required, Validators.email]] });

  submit() {
    if (this.form.invalid) return;
    const email = this.form.value.email!;
    this.sending = true;
    this.api.getUserByEmail(email).subscribe({
      next: user => {
        this.session.setEmail(user.email);
        this.router.navigateByUrl('/tasks');
        this.sending = false;
      },
      error: _ => {
        this.sending = false;
        const ref = this.dialog.open(ConfirmDialogComponent, {
          data: { title: 'Usuario no encontrado', message: `¿Crear usuario ${email}?`, confirmText: 'Crear', cancelText: 'Cancelar' }
        });
        ref.afterClosed().subscribe(ok => {
          if (ok) {
            this.sending = true;
            this.api.createUser(email).subscribe(u => {
              this.session.setEmail(u.email);
              this.router.navigateByUrl('/tasks');
              this.sending = false;
            }, () => this.sending = false);
          }
        });
      }
    });
  }
}
