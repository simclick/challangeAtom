import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', loadComponent: () => import('./modules/login-page/login-page.component').then(m => m.LoginPageComponent) },
  { path: 'tasks', loadComponent: () => import('./modules/tasks-page/tasks-page.component').then(m => m.TasksPageComponent) },
  { path: '**', redirectTo: '' }
];
